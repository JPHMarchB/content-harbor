from ._main import register_commands as register_commands
